## 2021-06-07
*Fixes*
- Location works both from location ID and normal name of the place 
- Updated NPM
- Actor works smoothly
